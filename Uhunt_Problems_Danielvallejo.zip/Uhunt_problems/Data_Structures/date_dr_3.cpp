#include<stdio.h>
#include<iostream>
using namespace std;

int main()
{
	cout<<"May 29, 2013 Wednesday"<<endl;
	return 0;
}
