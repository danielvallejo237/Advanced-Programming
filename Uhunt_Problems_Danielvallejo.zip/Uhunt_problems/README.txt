########################

En la presente carpeta se adjunta la lista de problemas correspondientes a la plataforma 
UHunt de la cuenta Danielvallejo, con las especificaciones solicitadas en la presentación 
al incicio del semestre, dentro de esta carpeta se encuentran los progmeas resueltos así
como aquellos con la etiqueta tried but not solved que no pudieron ser resueltos por mi.


Saludos cordiales,

Daniel Vallejo Aldana
