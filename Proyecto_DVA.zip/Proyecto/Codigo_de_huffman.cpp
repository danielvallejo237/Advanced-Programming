#include <bits/stdc++.h>

using namespace std;

/*El código de huffman tiene dos partes importantes, el vector de código de la palabra
y la tabla de código que será enviada para su decodificación*/

typedef vector<bool> code_v;
typedef map<char,code_v> t_codigo;

class HuffmanTree
{
    public:
    int freq;
    char c;
    HuffmanTree *left;
    HuffmanTree *right;
    HuffmanTree(char c, int freq, HuffmanTree *left=NULL, HuffmanTree *right=NULL)
    {
        this->c=c;
        this->freq=freq;
        this->left=left;
        this->right=right;
    }
    ~HuffmanTree()
    {
        delete left, delete right;
    }
    class Compare
    {
        public:
        bool operator()(HuffmanTree *a, HuffmanTree *b)
        {
            return a->freq > b->freq;
        }
    };
};


vector<pair<char,unsigned>> tabla_de_frecuencias(string inp)
{
    map<char,unsigned> fmap;
    vector<pair<char,unsigned>> cfvec;
    for(unsigned i=0;i<inp.size();i++)
    {
        if(fmap.find(inp[i])==fmap.end())
        {
            fmap.insert(make_pair(inp[i],1)); //se inserta la primera vez
        }
        else
        {
            fmap[inp[i]]+=1;
        }
    }
    for(map<char,unsigned>::iterator it=fmap.begin();it!=fmap.end();++it)
    {
        cfvec.push_back(make_pair(it->first,it->second));
    }
    return cfvec;
}

HuffmanTree *build (vector<pair<char,unsigned>> &alph)
{
    priority_queue<HuffmanTree *, vector<HuffmanTree*>, HuffmanTree::Compare > alph_heap;
    for (vector<pair<char,unsigned>>::iterator it=alph.begin();it!=alph.end();++it)
    {
        HuffmanTree *leaf=new HuffmanTree(it->first,it->second);
        alph_heap.push(leaf);
    }
    HuffmanTree *root=NULL;
    while(alph_heap.size()>1)
    {
        HuffmanTree *l,*r;
        l=alph_heap.top();
        alph_heap.pop();
        r=alph_heap.top();
        alph_heap.pop();
        root=new HuffmanTree(0,l->freq+r->freq,l,r);
        alph_heap.push(root);
    }

    return root;
}

void PrintHT(HuffmanTree *tree)
{
    deque< pair<HuffmanTree *, int> > q;
    q.push_back(make_pair(tree, 0));
    int nivelactual = -1;
    while (!q.empty()) {
        HuffmanTree *parent = q.front().first;
        int level = q.front().second;
        q.pop_front();
        if (nivelactual != level) {
            nivelactual = level;
            cout << "Level " << nivelactual << endl;
        }
        cout << parent->freq << " " << parent->c << endl;
        if (parent->left)
            q.push_back(make_pair(parent->left, level + 1));
        if (parent->right)
            q.push_back(make_pair(parent->right, level + 1));
    }
}

map<char,code_v> tabla_de_codigo(HuffmanTree *htree)
{
    t_codigo lookup;
    deque<pair<HuffmanTree *, code_v>>q;
    q.push_back(make_pair(htree,code_v()));
    while(!q.empty())
    {
        HuffmanTree *node, *l,*r;
        code_v code;
        node=q.front().first;
        code=q.front().second;
        q.pop_front();
        l=node->left;
        r=node->right;
        if(l)
        {
            code_v code_cp(code);
            q.push_back(make_pair(l,(code.push_back(0),code)));
            q.push_back(make_pair(r,(code_cp.push_back(1),code_cp)));
        }
        else
        {
            lookup.insert(make_pair(node->c,code));
            cout<<"("<<node->c<<", ";
            for (unsigned i=0;i<code.size();i++)
            {
                cout<<code[i];
            }
            cout<<")"<<endl;
        }
    }
    return lookup;
}

code_v encode(string input, t_codigo &lookup)
{
    code_v encoded;
    for(string::iterator it=input.begin();it!=input.end();++it)
    {
        code_v b=lookup[*it];
        encoded.insert(encoded.begin(),b.begin(),b.end());
    }
    return encoded;
}

char code_lookup(code_v::iterator &biter,const code_v::iterator &biter_end, const HuffmanTree *htree)
{
    const HuffmanTree *node=htree;
    while(true)
    {
        if(!node->left)
        {
            break;
        }
        if(biter==biter_end)
        {
            throw std::out_of_range("No mas bits");
        }
        if(*biter)
        {
            node=node->right;
        }
        else 
        {
            node=node->left;
        }
        ++biter;
    }
    return node->c;
}

string fix_string(string inp)
{
    list<char> result;
    string s;
    for(auto c: inp)
    {
        result.push_front(c);
    }
    for(list<char>::iterator it=result.begin();it!=result.end();++it)
    {
        s.push_back(*it);
    }
    return s;
}

string decode(code_v &codif, const HuffmanTree *htree)
{
    string result;
    code_v::iterator biter=codif.begin();
    while(true)
    {
        try 
        {
            result+=code_lookup(biter,codif.end(),htree);
        }
        catch(const std::out_of_range(&oor))
        {
            break;
        }
    }
    return result;
}

//FUNCIONES AUXILIARES PARA LECTURA Y ESCRITURA DE ARCHIVOS

string bitvec_to_string(code_v &bitvec)
{
    string result;
    size_t nbits;
    nbits=bitvec.size() & 7;
    result+=static_cast<char>(nbits);
    char byte=0;
    for(unsigned i=0;i<bitvec.size();i++)
    {
        unsigned boff=i&7;
        byte |=bitvec[i]<<boff;
        if(boff==7)
        {
            result+=byte;
            byte=0;
        }
    }
    if(nbits)
    {
        result+=byte;
    }
    return result;
}

code_v string_to_bitvec(string packed)
{
    code_v result;
    assert(packed.size());
    if(packed.size()==1)
    {
        assert(packed[0]==0);
        return result;
    }
    unsigned nbits=packed[0];
    for(string::iterator it=packed.begin()+1;it!=packed.end();++it)
    {
        for(unsigned i=0;i<8;i++)
        {
            result.push_back((*it>>i)&1);
        }
    }
    if(nbits)
    {
        for(unsigned i=0;i<(8-nbits);i++)
        {
            result.pop_back();
        }
    }
    return result;
}
int main(int argc, char *argv[])
{
    assert(argc==3);
    ifstream ifs(argv[1]);
    string s((istreambuf_iterator<char>(ifs) ),(istreambuf_iterator<char>() ) );
    vector< pair<char, unsigned> > cfvec = tabla_de_frecuencias(s);
    HuffmanTree *htree = build(cfvec);
    t_codigo codetbl=tabla_de_codigo(htree);
    code_v codigo=encode(s,codetbl);
    cout<<"Frase: "<<s<<endl;
    cout<<"Codificada: "<<endl;
    for(code_v::iterator it=codigo.begin();it!=codigo.end();++it) cout<<*it;
    cout<<endl;
    cout << "\nCodificado (Razon de compresion: " << (codigo.size() + 7) / 8 << "/" << s.size() << " o " << ((float)(codigo.size() / 8) / s.size()) << "):" << endl;
    string decoded=decode(codigo,htree);
    string fine=fix_string(decoded);
    cout<<"\nDecodificada: "<<fine<<endl;
    string packed=bitvec_to_string(codigo);
    ofstream codigo_seco;
    codigo_seco.open("Codificado.txt");
    for(code_v::iterator it=codigo.begin();it!=codigo.end();++it) codigo_seco<<*it;
    codigo_seco<<endl;
    codigo_seco.close();
    ofstream outfile;
    outfile.open(argv[2]);
    outfile<<packed<<endl;
    outfile.close();
    code_v t1=string_to_bitvec(packed);
    string s1=decode(t1,htree);
    ofstream decomp;
    decomp.open("Decodificado.txt");
    decomp<<fix_string(s1)<<endl;
    decomp.close();
    delete htree;
    return 0;
}